#coding=utf-8
import xml.etree.cElementTree as ET
import re


class divider:
    def __init__(self):
        self.tree=ET.parse(".\\xml_files\\oval.xml")
        self.root=self.tree.getroot()
        self.path=0
        self.q=1
        self.flag=1
        self.def_ids=[]
        self.test_ids=[]
        self.object_ids=[]
        self.state_ids=[]
        self.var_ids=[]
        self.family="windows"
        self.key_words="windows"

    def set_path(self,path):
        self.path=path

    def config(self,family,keywords):
        self.family=family
        self.key_words=keywords

    def search(self):
        a = 0
        pattern = ".*"+self.key_words+".*"
        for definitions in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
            for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                flag = 0
                for metadata in definition.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}metadata"):
                    for description in metadata.findall(
                            "{http://oval.mitre.org/XMLSchema/oval-definitions-5}description"):
                        for affected in metadata.findall(
                                "{http://oval.mitre.org/XMLSchema/oval-definitions-5}affected"):
                            if affected.get("family") == self.family:
                                if re.match(pattern, str(description.text)):
                                    a += 1
                                    flag = 1
                                    print(description.text)
                if (flag == 1):
                    a += 1
        print("共检索到",a,"条相关漏洞定义")


    def divide(self):
        a = 0
        pattern = ".*"+self.key_words+".*"

        while(self.q):
            self.q=0
            # 1.由关键字初步检索出有效def_id
            for definitions in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
                for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                    flag = 0
                    for metadata in definition.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}metadata"):
                        for description in metadata.findall(
                                "{http://oval.mitre.org/XMLSchema/oval-definitions-5}description"):
                            for affected in metadata.findall(
                                    "{http://oval.mitre.org/XMLSchema/oval-definitions-5}affected"):
                                if affected.get("family") == self.family:
                                    if re.match(pattern, str(description.text)):
                                        flag = 1
                    if (flag == 1) and definition.get("id") not in self.def_ids:
                        self.def_ids.append(definition.get("id"))

            # 2.找出def_id引用到的def_id
            a = []
            b = []
            for definitions in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
                for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                    for criteria in definition.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}criteria"):
                        if definition.get("id") in self.def_ids:
                            a.append(criteria)
            for x in a:
                for y in x.getchildren():
                    if "definition_ref" in y.attrib:
                        if y.attrib["definition_ref"] not in self.def_ids:
                            self.def_ids.append(y.attrib["definition_ref"])
                            self.q=1
                    else:
                        b.append(y)
            while (b):
                a = []
                a += b
                b = []
                for x in a:
                    for y in x.getchildren():
                        if "definition_ref" in y.attrib:
                            if y.attrib["definition_ref"] not in self.def_ids:
                                self.def_ids.append(y.attrib["definition_ref"])
                                self.q=1
                        else:
                            b.append(y)

        #3.由def_id来获得有效的test_id
        a = []
        b = []
        for definitions in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
            for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                if definition.get("id") in self.def_ids:
                    for criteria in definition.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}criteria"):
                        a.append(criteria)
        for x in a:
            for y in x.getchildren():
                if "test_ref" in y.attrib:
                    self.test_ids.append(y.attrib["test_ref"])
                else:
                    b.append(y)
        while (b):
            a = []
            a += b
            b = []
            for x in a:
                for y in x.getchildren():
                    if "test_ref" in y.attrib:
                        self.test_ids.append(y.attrib["test_ref"])
                    else:
                        b.append(y)

         # 4.由test_id获取有效object_id和state_id

        for tests in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}tests"):
            for test in tests.getchildren():
                if test.get("id") in self.test_ids:
                    # print(test.get("id"))
                    for ref in test.getchildren():
                        if "object_ref" in ref.attrib:
                            self.object_ids.append(ref.attrib["object_ref"])
                        if "state_ref" in ref.attrib:
                            self.state_ids.append(ref.attrib["state_ref"])



        while(self.flag):
            self.flag=0
            # 5.找出object中引用到的object_id和state_id
            a = []
            b = []
            one = ".*obj.*"
            two = ".*ste.*"
            for objects in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}objects"):
                for object in objects.getchildren():
                    if object.get("id") in self.object_ids:
                        for set in object.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}set"):
                            a.append(set)
            for x in a:
                for y in x.getchildren():
                    if re.match(one, str(y.text)):
                        if str(y.text) not in self.object_ids:
                            self.object_ids.append(str(y.text))
                    else:
                        if re.match(two, str(y.text)):
                            if str(y.text) not in self.state_ids:
                                self.state_ids.append(str(y.text))
                        else:
                            b.append(y)
            while (b):
                a = []
                a += b
                b = []
                for x in a:
                    for y in x.getchildren():
                        if re.match(one, str(y.text)):
                            if str(y.text) not in self.object_ids:
                                self.object_ids.append(str(y.text))
                        else:
                            if re.match(two, str(y.text)):
                                if str(y.text) not in self.state_ids:
                                    self.state_ids.append(str(y.text))
                            else:
                                b.append(y)

            # 6.由object_id获取有效variable id

            for objects in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}objects"):
                for object in objects.getchildren():
                    if object.get("id") in self.object_ids:
                        # print(object.get("id"))
                        for path in object.getchildren():
                            if "var_ref" in path.attrib:
                               self.var_ids.append(path.attrib["var_ref"])

            # 7.获取有效variable id中引用到的obj_id
            a = []
            b = []
            for variables in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}variables"):
                for var in variables.getchildren():
                    if var.get("id") in self.var_ids:
                        a.append(var)
            for x in a:
                for y in x.getchildren():
                    if "object_ref" in y.attrib:
                        if y.attrib["object_ref"] not in self.object_ids:
                            self.object_ids.append(y.attrib["object_ref"])
                            self.flag=1
                    else:
                        if "var_ref" in y.attrib:
                             if y.attrib["var_ref"] not in self.var_ids:
                                 self.var_ids.append(y.attrib["var_ref"])
                                 self.flag=1
                        else:
                            b.append(y)
            while (b):
                a = []
                a += b
                b = []
                for x in a:
                    for y in x.getchildren():
                        if "object_ref" in y.attrib:
                            if y.attrib["object_ref"] not in self.object_ids:
                                self.object_ids.append(y.attrib["object_ref"])
                                self.flag=1
                        else:
                            if "var_ref" in y.attrib:
                                if y.attrib["var_ref"] not in self.var_ids:
                                    self.var_ids.append(y.attrib["var_ref"])
                                    self.flag = 1
                            else:
                                b.append(y)


        #除去所有多余项目
        for definitions in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
            for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                if definition.get("id") not in self.def_ids:
                    definitions.remove(definition)

        for tests in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}tests"):
            for test in tests.getchildren():
                if test.get("id") not in self.test_ids:
                    tests.remove(test)

        for objects in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}objects"):
            for object in objects.getchildren():
                if object.get("id") not in self.object_ids:
                    objects.remove(object)

        for states in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}states"):
            for state in states.getchildren():
                if state.get("id") not in self.state_ids:
                    states.remove(state)

        for variables in self.root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}variables"):
            for var in variables.getchildren():
                if var.get("id") not in self.var_ids:
                    variables.remove(var)

        #写出结果
        self.tree.write(".\\xml_files\\"+self.family+"\\"+self.key_words+".xml")

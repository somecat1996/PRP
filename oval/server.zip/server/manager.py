#coding=utf-8
from config import *
from task import *
import threading

class manager:
    open=0

    #name means the name you give the task
    def __init__(self):
        self.tasks = {}
        self.results = {}
        if manager.open!=0:
            print("the manager is already running,no need to start another")
        else:
            manager.open=1
            print u"manager开始启动...."

    #create a new task
    def create_task(self,name):
        if(name in self.tasks):
            print u"错误：同名任务已存在"
            return
        else:
            task1=task(name)
            self.tasks[name]=task1

    #config the task
    def config(self,name,scantype,ipaddr):
        if(name in self.tasks):
           self.tasks[name].set_config(config(scantype,ipaddr))
        else:
           print u"任务不存在"

    #use another port
    def set_port(self,name,port):
        if(name in self.tasks):
           self.tasks[name].set_port(port)
        else:
           print u"任务不存在"

    #start the task
    def task_start(self,name):
        t=threading.Thread(target=self.tasks[name].task_start)
        t.start()
        self.results[name]=self.tasks[name].get_result()
        return t

    #get the result of the task
    #def get_result(self,name):
    #    return self.results[name]

    #show the result in a simpler and more direct way
    def parse_result(self,name):
        self.results[name].parse()

     #save the result to a specific xml file
    def save_result_to_xml(self,name,path):
        self.results[name].save_to(path)


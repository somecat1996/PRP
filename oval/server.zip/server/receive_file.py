#coding=utf-8
from socket import *
import struct

def receive_file(socket,path_to_save):
    BUFSIZE = 1024
    FILEINFO_SIZE = struct.calcsize('128s32sI8s')
    fhead = socket.recv(FILEINFO_SIZE)
    filename, filesize = struct.unpack('128sl', fhead)
    # print filename,temp1,filesize,temp2
    filename = filename.decode("gb2312")
    filename = path_to_save +"/"+ filename.strip('\x00')
    fp = open(filename, 'wb')
    restsize = filesize
    print u"正在接收文件... "
    while 1:
        if restsize > BUFSIZE:
            filedata = socket.recv(BUFSIZE)
        else:
            filedata = socket.recv(restsize)
        if not filedata: break
        fp.write(filedata)
        restsize = restsize - len(filedata)
        if restsize == 0:
            break

    print u"接收文件完毕，正在断开连接..."
    fp.close()


#configuration information of a task
class config:
    def __init__(self,scantype,ipaddr):
        self.scantype=scantype
        self.target=ipaddr

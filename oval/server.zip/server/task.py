#coding=utf-8
import time
from config import *
from result import *

from connection import *


class task:
    def __init__(self,name):
        self.name=name
        self.start_time=time.ctime(time.time())
        print u"任务建立：",self.name
        print u"时间:",self.start_time
        self.config=0
        self.connection=connection()
        self.end_time=0
        self.start_code="fresh"
        self.error=[u"无配置信息",u"连接目标失败",u"传送开始状态失败",u"传送配置信息失败",u"获取文件信息失败",u"传送漏洞定义文件失败",u"获取结果失败",u"任务完成"]
        self.status=[u"设置配置信息",u"连接目标...",u"传送开始状态...",u"传送配置信息...",u"获取文件信息...",u"传送漏洞定义文件...",u"获取结果...",u"任务完成"]
        self.status_list=[0,0,0,0,0,0,0]
        self.count=0

    #config the task
    def set_config(self,config):
        self.config=config
        print u"配置成功"

    #use another port. default=8000
    def set_port(self,port):
        self.connection.set_port(port)

    def task_start(self):
        if(self.start_code=="inprogress"):
            self.start_code="restart"
        if(self.start_code=="fresh"):
            self.count=0
            #step 1
            if self.config==0:
                print u"无配置信息"
                return False
            self.status_list[self.count]=1
            self.count+=1

            self.connection.set_target(self.config.target,self.name)

            #step 2
            if(self.connection.connect()):
                self.status_list[self.count]=1
                self.count+=1
            else:
                return False

            #step 3
            if(self.connection.send_start_code(self.start_code)):
                self.status_list[self.count] = 1
                self.count += 1
            else:
                return False
            self.start_code="inprogress"
        else:
            print u"开始恢复任务..."
            if(self.connection.connect()):
               print u"重新连接成功"
            else:
               print u"无法连接"
               return False
            if (self.connection.send_start_code(self.start_code)):
               self.start_code = "inprogress"
               print u"中断状态确认成功"
            else:
               print u"中断状态确认失败"
               return False

        # step 4
        if(self.count<4):
            if(self.connection.trans_config(self.config)):
                self.status_list[self.count] = 1
                self.count += 1
            else:
                self.start_code="restart"
                return False

        # step 5
        if(self.count<5):
            info=self.connection.get_xml_info()
            if(info):
                self.status_list[self.count] = 1
                self.count += 1
            else:
                self.start_code = "restart"
                return False

        # step 6
        if(self.count<6):
            if(len(info)==1):
                print u"所需xml文件已存在,扫描开始执行..."
                self.status_list[self.count] = 1
                self.count += 1
            else:
                if(self.connection.trans_xml(info,self.config)):
                    self.status_list[self.count] = 1
                    self.count += 1
                else:
                    self.start_code = "restart"
                    return False

        # step 7
        if(self.count<7):
            print u"等待结果返回......"
            print "     "
            print "     "
            if(self.connection.receive_result()):
                self.status_list[self.count] = 1
                self.count += 1
            else:
                self.start_code = "restart"
                return False
            self.end_time=time.ctime(time.time())
            print u"任务完成"
            print u"时间：",self.end_time
            self.start_code="finished"

    # get the packed result of the task
    def get_result(self):
        return result("./results/"+self.name)

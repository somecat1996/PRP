#coding=utf-8
#the result of a task
import xml.etree.cElementTree as ET
import shutil
import os
import string, re
class result:
    def __init__(self,xml_path):
        self.xml_path=xml_path

    #show the test results in the sml file in a simpler and more direct way
    def parse(self):
        count = 0
        vuln_ids = []
        vuln=[]
        inventory=[]
        sysinfo={}
        flag=False
        for dirpath, dirnames, filenames in os.walk(self.xml_path):
            for x in filenames:
                   vuln_ids=[]
                   tree = ET.parse(os.path.join(dirpath, x))
                   root = tree.getroot()
                   for results in root.findall("{http://oval.mitre.org/XMLSchema/oval-results-5}results"):
                     for system in results.findall("{http://oval.mitre.org/XMLSchema/oval-results-5}system"):
                       for definitions in system.findall("{http://oval.mitre.org/XMLSchema/oval-results-5}definitions"):
                          for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-results-5}definition"):
                              if definition.get("result") == "true":
                                   count += 1
                                   if str(definition.get("definition_id")) not in vuln_ids:
                                       vuln_ids.append(str(definition.get("definition_id")))
                       for oval_system_characteristics in system.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}oval_system_characteristics"):
                           for system_info in oval_system_characteristics.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}system_info"):
                               for os_name in system_info.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}os_name"):
                                   sysinfo["os_name"]=str(os_name.text)
                               for os_version in system_info.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}os_version"):
                                   sysinfo["os_version"]=str(os_version.text)
                               for arch in system_info.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}architecture"):
                                   sysinfo["architecture"]=str(arch.text)
                               for host_name in system_info.findall("{http://oval.mitre.org/XMLSchema/oval-system-characteristics-5}primary_host_name"):
                                   sysinfo["host_name"]=str(host_name.text)
                   if(vuln_ids):
                       flag=True
                       for oval_definitions in root.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}oval_definitions"):
                          for definitions in oval_definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definitions"):
                             for definition in definitions.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}definition"):
                                if str(definition.get("id")) in vuln_ids:
                                    temp=[]
                                    temp.append(str(definition.get("class")))
                                    for metadata in definition.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}metadata"):
                                         for title in metadata.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}title"):
                                              temp.append(str(title.text))
                                         for reference in metadata.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}reference"):
                                              temp.append(str(reference.get("ref_id")))
                                         for description in metadata.findall("{http://oval.mitre.org/XMLSchema/oval-definitions-5}description"):
                                              temp.append(str(description.text))
                                         if(str(definition.get("class"))=="vulnerability"):
                                              vuln.append(temp)
                                         else:
                                              inventory.append(temp)
        print "\n\n\n\n\n"
        print "--------------------------------------------------------------------------------"
        print u"            扫描结果           共",count,u"条漏洞"
        print "--------------------------------------------------------------------------------"
        print u"目标操作系统：",sysinfo["os_name"]
        print u"版本：",sysinfo["os_version"]
        print u"结构体系：",sysinfo["architecture"]
        print u"主机名：",sysinfo["host_name"]
        print "\n\n"
        if(not flag):
            print "No vulnerability found"
            print "\n\n"
        else:
            for x in vuln:
                print u"漏洞名称：",x[1]
                print u"漏洞类型：",x[0]
                print u"CVE编号：",x[2]
                print u"漏洞描述：",x[3]
                print "\n\n"
        print "--------------------------------------------------------------------------------"
        print u"        扫描结果    共",len(vuln),u"条漏洞         ",len(inventory),u"项软件安装"
        print "--------------------------------------------------------------------------------"


    #save the result to a specific xml file
    def save_to(self,path):
        for dirpath, dirnames, filenames in os.walk(self.xml_path):
            for x in filenames:
                 shutil.copyfile(os.path.join(dirpath, x),path)
#coding=utf-8
import re
from socket import *

from send_file import *
from receive_file import *

from zipxml import *
from unzipxml import *

class connection():
    def __init__(self):
        self.s=socket(AF_INET,SOCK_STREAM)
        self.host=0
        self.taskname=""
        self.port=8000

    #set the target machine
    def set_target(self,host,taskname):
        self.host=host
        self.taskname=taskname
        print u"目标设置成功",self,host

    #use another port
    def set_port(self,port):
        self.port=port
    #connect the target machine
    def connect(self):
        try:
            print u"正在请求连接..."
            self.s.connect((self.host,self.port))
            print u"连接成功"
            return True
        except:
            return False

    #send the start code
    def send_start_code(self,start_code):
        temp=start_code+" "+self.taskname
        try:
            print u"正在传送任务状态"
            self.s.send(temp.encode("gb2312"))
            print u"任务状态传送成功"
            return True
        except Exception:
            print u"任务状态传送失败"
            return False

    #sent the config infomation to the target machine
    def trans_config(self,config):
         scaninfo=self.taskname
         for x in config.scantype:
             temp=" "+x
             scaninfo +=temp
         try:
             print u"正在传送配置信息"
             self.s.send(scaninfo.encode("gb2312"))
             print u"配置信息传送成功"
             return True
         except Exception:
             print u"配置信息传送失败"
             return False

    #getting the information of xml files on the target machine
    #the system information is at the end of the list
    def get_xml_info(self):
        try:
            temp=""
            print u"正在获取目标文件信息"
            while True:
                buf = self.s.recv(4096)
                temp+=buf.decode("gb2312")
                if  len(buf)<4096:
                    break
                print(temp)
            print u"文件信息获取成功"
            a=temp.split()
            print(a)
            return a
        except Exception:
            print u"文件信息获取失败"
            return False

    #tranfer the xml files for scan to the target machine
    def trans_xml(self,info,config):
         sysinfo=info[-1]
         fileholder="./xml_files"
         pattern=".*Windows.*"
         if re.match(pattern,sysinfo):
             fileholder+="/Windows"
         else:
             fileholder+="/Unix"
         file_to_send="./file_to_send/file_to_send.zip"
         #try:
         print u"开始压缩xml文件"
         print(fileholder)
         zipxml(file_to_send,fileholder,info)
         print u"xml文件压缩完成"
         #except:
          #  return False
         try:
            print u"开始传送xml文件"
            send_file(self.s,file_to_send)
            print u"文件传送完成"
            return True
         except:
            print u"传送xml文件失败"
            os.remove(file_to_send)
            return False

    #receive  result from target host
    def receive_result(self):
         try:
             receive_file(self.s,"./file_received")
         except:
             return False
         #unzip the results
         unzipxml(self.taskname)




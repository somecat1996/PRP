from result import *
re=result(".\\results\\t")
re.parse()
#coding=utf-8
import zipfile
import shutil
import os

def unzipxml(taskname):
    filename="./file_received/return_result.zip"
    filedir="./results"
    fz = zipfile.ZipFile(filename,'r')
    for file in fz.namelist():
        print u"正在解压",file  #打印zip归档中目录
        fz.extract(file,filedir)
    if (not os.path.exists("./results/" + taskname)):
        os.mkdir("./results/"+taskname)
    for dirpath, dirnames, filenames in os.walk("./results/Program Files/UserAgent/results"):
        for filename1 in filenames:
            print u"正在移动文件", filename1
            shutil.copy(os.path.join(dirpath, filename1), "./results/"+ taskname + "/"+ filename1)
    fz.close()
    os.remove(filename)
    shutil.rmtree("./results/Program Files")

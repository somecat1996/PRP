#!/bin/sh
CHECK_UNZIP=`which unzip`
CHECK_MD5SUM=`which md5sum`
CHECK_WGET=`which wget`
CHECK_CURL=`which curl`
WGET_CODE=1
CURL_CODE=1
version_current=0
md5_flag=1
chk_system_tools(){
	  echo "[i] Searching for required system tools (look for warnings)..."

		    if [ -z "$CHECK_MD5SUM" ]; then
			        echo "[w] Warning: MD5SUM not found";
	  	exit 0
			  fi

			    if [ -z "$CHECK_UNZIP" ]; then
				        echo "[w] Warning: UNZIP not found";
			exit 0
				  fi

				    if [ -z "$CHECK_WGET" ]; then
					        echo "[w] Warning: wget not found";
				WGET_CODE=0
					  fi

					    if [ -z "$CHECK_CURL" ]; then
						        echo "[w] Warning: curl not found";
					CURL_CODE=0
						  fi

						    if [ -z "$CHECK_WGET" -a -z "$CHECK_CURL" ]; then
							        exit 0
									  fi

									    echo "If you did not get any warnings, that means you have all tools required"

									      echo "Note that it is recommended to have md5sum and one of the following: unzip, wget or curl."
}

get_url(){
	  if [ $WGET_CODE -eq 1 ]; then
		      echo "getting url using wget"
			      	eval "wget oval.cisecurity.org/repository/download -O oval.html"
					if [ $? -ne 0 ];then
								echo "Fail:oval data source not reachable"
											exit 0
												fi
													URL=`cat oval.html | grep "href.*zip" | sed "s/ /\n/g" | grep "href.*zip" | sed -n "1p" | sed 's/"/\n/g' | grep ".*zip"`
													  
													  else
														      if [ $CURL_CODE -eq 1 ]; then
															              echo "getting url using curl"
																	      		eval "curl oval.cisecurity.org/repository/download -o oval.html"
																					if [ $? -ne 0 ];then
																									echo "Fail:oval data source not reachable"
																													exit 0
																															fi
																																    URL=`cat oval.html | grep "href.*zip" | sed "s/ /\n/g" | grep "href.*zip" | sed -n "1p" | sed 's/"/\n/g' | grep ".*zip"`
																																    	fi
																																	  fi
																																	  		
}

cmp_version(){
	  old_url=`sed -n "1p" old_url`
		    if [ "$old_url" = "$URL" ]; then
			        version_current=1
					  fi
}

get_file(){
	  if [ $WGET_CODE -eq 1 ]; then
		      echo "downloading file using wget"
			      	eval "wget $URL"
				  else
					      if [ $CURL_CODE -eq 1 ]; then
						             echo "downloading file using curl"
								     	   eval "curl -O $URL"
									   	fi
										  fi
}

do_check_md5(){
	  echo "Checking md5......"
		    eval "$CHECK_MD5SUM -c old_md5.md5"
		      if [ $? -ne 0 ] ; then
			          echo "md5 not ok"
					      echo "Replacing the old version with new version..."
					      	md5_flag=0
						  else
							  	echo "Oval definitions already up to date"
									eval "rm -r oval.xml.zip"
									  fi
}


chk_system_tools
get_url
cmp_version
get_file
if [ $version_current -eq 1 ]; then
  do_check_md5
    if [ $md5_flag -eq 0 ]; then
         eval "rm -r ../xml_files/oval.xml"
	 	 echo "unzipping file"
		      eval "unzip oval.xml.zip -d ../xml_files"
		           echo "Replacing old md5"
			        eval "rm -r old_md5.md5"
				     eval "md5sum oval.xml.zip> old_md5.md5"
				     	 eval "rm -r oval.xml.zip"
					      eval "echo $URL >> old_url "
					      	 echo "Update is done."
						   fi
						   else
						     	eval "rm -r ../xml_files/oval.xml"
								echo "unzipping file"
								    eval "unzip oval.xml.zip -d ../xml_files"
								        echo "Replacing old md5"
									    eval "rm -r old_md5.md5"
									        eval "md5sum oval.xml.zip> old_md5.md5"
											eval "rm -r oval.xml.zip"
											    eval "echo $URL >> old_url "
											        echo "Update is done."
												fi


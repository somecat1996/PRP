#coding=utf-8
import zipfile
import os

def zipxml(target,startdir,info):
    compression = zipfile.ZIP_DEFLATED
    f = zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED)
    for dirpath, dirnames, filenames in os.walk(startdir):
        for filename in filenames:
            if filename in info:
                print u"正在压缩",os.path.join(dirpath,filename)
                f.write(os.path.join(dirpath,filename))
    f.close()
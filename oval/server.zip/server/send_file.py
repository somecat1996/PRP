#coding=utf-8
from socket import *
import os
import struct

def send_file(sendSock,filepath):
    BUFSIZE = 1024
    filename="file_to_send.zip"
    fhead=struct.pack('128sl',filename.encode('gb2312'),os.stat(filepath).st_size)
    sendSock.send(fhead)
    fp = open(filepath,'rb')
    while 1:
        filedata = fp.read(BUFSIZE)
        if not filedata: break
        sendSock.send(filedata)
    print u"文件传送完毕，正在删除原文件"
    fp.close()
    os.remove(filepath)
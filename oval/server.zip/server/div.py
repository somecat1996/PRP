#coding=utf-8
from divider import *

_divider=divider()
_divider.config("windows","Office")
_divider.divide()

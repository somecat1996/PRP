
from manager import *

taskname="test5"

#start the manager
scan_manager=manager()

#create task
scan_manager.create_task(taskname)

#config the task
#["Explorer.xml","Adobe.xml","database.xml","DNS.xml","Firefox.xml","FTP.xml","HTTP.xml","Office.xml","Opera.xml","Oracle.xml","others.xml","sys_kernel.xml","sys_service.xml","web.xml","wireshark.xml"]
scan_manager.config(taskname,["Firefox.xml"],"192.168.0.101")

#scan_manager.tasks[taskname].connection.set_target(scan_manager.tasks[taskname].config.target,scan_manager.tasks[taskname].name)
#scan_manager.tasks[taskname].start_code="restart"
#scan_manager.tasks[taskname].count=6
#start the task
#try:
t=scan_manager.task_start(taskname)
t.join()
#disaplay the result
scan_manager.parse_result(taskname)
